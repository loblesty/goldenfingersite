import pygame
import sys
import time
import json
import hashlib

pygame.init()

icon = pygame.image.load("icon.png")  # заміни "icon.png" на назву свого файлу
pygame.display.set_icon(icon)


def generate_hash(coins, autoclick, upgrade_cost, achievements):
    # Включаємо achievements у хеш для захисту
    ach_str = ",".join(sorted(achievements))
    data_str = f"{coins}:{autoclick}:{upgrade_cost}:{ach_str}"
    return hashlib.sha256(data_str.encode()).hexdigest()

WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Клікер")

WHITE = (255, 255, 255)
GRAY = (200, 200, 200)
BLACK = (0, 0, 0)
GOLD = (255, 215, 0)

font = pygame.font.SysFont("Arial", 28)

game_state = "menu"

coins = 0
autoclick = 0
upgrade_cost = 50
last_autoclick_time = time.time()
achievement_message = ""
achievement_message_time = 0
MESSAGE_DURATION = 3  # секунди

all_achievements = [
    ("10 монет", lambda c, a: c >= 10),
    ("100 монет", lambda c, a: c >= 100),
    ("1000 монет", lambda c, a: c >= 1000),
    ("10000 монет", lambda c, a: c >= 10000),
    ("100000 монет", lambda c, a: c >= 100000),
    ("10 автоклікерів", lambda c, a: a >= 10),
    ("100 автоклікерів", lambda c, a: a >= 100),
    ("1000 автоклікерів", lambda c, a: a >= 1000),
    ("10000 автоклікерів", lambda c, a: a >= 10000),
    ("100000 автоклікерів", lambda c, a: a >= 100000),
]

achievements_unlocked = set()

# Завантаження прогресу
try:
    with open("save.json", "r") as f:
        data = json.load(f)
        coins = data.get("coins", 0)
        autoclick = data.get("autoclick", 0)
        upgrade_cost = data.get("upgrade_cost", 50)
        saved_achievements = set(data.get("achievements", []))
        saved_hash = data.get("hash", "")

        if saved_hash != generate_hash(coins, autoclick, upgrade_cost, saved_achievements):
            print("❌ Чіт виявлено! Прогрес скинуто.")
            coins = 0
            autoclick = 0
            upgrade_cost = 50
            achievements_unlocked = set()
        else:
            achievements_unlocked = saved_achievements
except (FileNotFoundError, json.JSONDecodeError):
    achievements_unlocked = set()

click_button = pygame.Rect(200, 150, 200, 100)
upgrade_button = pygame.Rect(400, 20, 160, 50)
play_button = pygame.Rect(WIDTH // 2 - 100, 200, 200, 60)
achievements_button = pygame.Rect(WIDTH // 2 - 100, 280, 200, 60)
back_button = pygame.Rect(WIDTH // 2 - 60, HEIGHT - 70, 120, 50)

clock = pygame.time.Clock()

while True:
    screen.fill(WHITE)

    if game_state == "menu":
        title_text = font.render("Золоте Натискання", True, BLACK)
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, 100))

        pygame.draw.rect(screen, GOLD, play_button)
        play_text = font.render("Почати гру", True, BLACK)
        screen.blit(play_text, (play_button.x + 25, play_button.y + 15))

        pygame.draw.rect(screen, GOLD, achievements_button)
        achievements_text = font.render("Досягнення", True, BLACK)
        screen.blit(achievements_text, (achievements_button.x + 20, achievements_button.y + 15))

    elif game_state == "playing":
        current_time = time.time()
        if current_time - last_autoclick_time >= 1:
            coins += autoclick
            last_autoclick_time = current_time

        pygame.draw.rect(screen, GOLD, click_button)
        text_click = font.render("Клік!", True, BLACK)
        screen.blit(text_click, (click_button.x + 60, click_button.y + 35))

        pygame.draw.rect(screen, GRAY, upgrade_button)
        text_upgrade = font.render(f"Автоклік ({upgrade_cost})", True, BLACK)
        screen.blit(text_upgrade, (upgrade_button.x + 5, upgrade_button.y + 10))

        coin_text = font.render(f"Монети: {coins}", True, BLACK)
        auto_text = font.render(f"Автоклікери: {autoclick}", True, BLACK)
        screen.blit(coin_text, (20, 20))
        screen.blit(auto_text, (20, 60))

        # Перевірка нових досягнень
        for name, condition in all_achievements:
            if condition(coins, autoclick) and name not in achievements_unlocked:
                achievements_unlocked.add(name)
                achievement_message = f"Досягнення: {name}!"
                achievement_message_time = time.time()

    elif game_state == "achievements":
        screen.fill(WHITE)
        title = font.render("Досягнення", True, BLACK)
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 20))

        y = 80
        for name, condition in all_achievements:
            unlocked = name in achievements_unlocked
            color = (0, 150, 0) if unlocked else (150, 150, 150)
            text = font.render(name, True, color)
            screen.blit(text, (50, y))
            y += 40

        pygame.draw.rect(screen, GOLD, back_button)
        back_text = font.render("Назад", True, BLACK)
        screen.blit(back_text, (back_button.x + 25, back_button.y + 10))

    # Відображення повідомлення про досягнення
    if achievement_message != "" and time.time() - achievement_message_time < MESSAGE_DURATION:
        msg_surf = font.render(achievement_message, True, (255, 100, 0))
        screen.blit(msg_surf, (WIDTH // 2 - msg_surf.get_width() // 2, 10))
    else:
        achievement_message = ""

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            # Збереження з оновленим хешем
            with open("save.json", "w") as f:
                json.dump({
                    "coins": coins,
                    "autoclick": autoclick,
                    "upgrade_cost": upgrade_cost,
                    "achievements": list(achievements_unlocked),
                    "hash": generate_hash(coins, autoclick, upgrade_cost, achievements_unlocked)
                }, f)
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN:
            if game_state == "menu":
                if play_button.collidepoint(event.pos):
                    game_state = "playing"
                elif achievements_button.collidepoint(event.pos):
                    game_state = "achievements"
            elif game_state == "playing":
                if click_button.collidepoint(event.pos):
                    coins += 1
                if upgrade_button.collidepoint(event.pos) and coins >= upgrade_cost:
                    coins -= upgrade_cost
                    autoclick += 1
                    upgrade_cost = int(upgrade_cost * 1.5)
            elif game_state == "achievements":
                if back_button.collidepoint(event.pos):
                    game_state = "menu"

    pygame.display.flip()
    clock.tick(60)
